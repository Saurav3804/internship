export enum Role {
  Admin = 'admin',
  User = 'user',
}
