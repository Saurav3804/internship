﻿namespace Mission.Entities.Models
{
    public class AddMissionSkillRequestModel
    {
        public string SkillName { get; set; }

        public string Status { get; set; }
    }
}
